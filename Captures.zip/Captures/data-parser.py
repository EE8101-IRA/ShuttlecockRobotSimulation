import pandas

data = pandas.read_csv("data_bg_near.csv")

width = 512
height = 512

data['center-x'] = (0.5 * (data['xmin'] + data['xmax'])) / width
data['center-y'] = (0.5 * (data['ymin'] + data['ymax'])) / height

data['width'] = (data['xmax'] - data['xmin']) / width
data['height'] = (data['ymax'] - data['ymin']) / height

data.to_csv('data_bg_near_new.csv', index=False)